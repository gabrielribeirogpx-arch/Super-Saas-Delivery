from types import SimpleNamespace

from starlette.requests import Request
import pytest

from app.services.tenant_resolver import TenantResolutionError, TenantResolver


def _build_request(path: str, headers: dict[str, str] | None = None, path_params: dict | None = None) -> Request:
    scope = {
        "type": "http",
        "method": "GET",
        "path": path,
        "query_string": path.split("?", 1)[1].encode() if "?" in path else b"",
        "headers": [(k.lower().encode(), v.encode()) for k, v in (headers or {}).items()],
        "path_params": path_params or {},
    }
    request = Request(scope)
    request.state.tenant = None
    return request


def test_resolve_tenant_id_from_query_param():
    request = _build_request("/api/dashboard/overview?tenant_id=21")

    tenant_id = TenantResolver.resolve_tenant_id_from_request(request)

    assert tenant_id == 21


def test_resolve_tenant_id_from_header_when_missing_query():
    request = _build_request("/api/dashboard/overview", headers={"x-tenant-id": "42"})

    tenant_id = TenantResolver.resolve_tenant_id_from_request(request)

    assert tenant_id == 42


def test_resolve_tenant_id_prioritizes_explicit_parameter():
    request = _build_request("/api/dashboard/overview?tenant_id=21", headers={"x-tenant-id": "42"})

    tenant_id = TenantResolver.resolve_tenant_id_from_request(request, tenant_id=7)

    assert tenant_id == 7


def test_resolve_tenant_id_uses_jwt_tenant_and_ignores_header_spoof(monkeypatch):
    request = _build_request(
        "/api/dashboard/overview",
        headers={
            "authorization": "Bearer secure-token",
            "x-tenant-id": "42",
        },
    )
    monkeypatch.setattr(
        "app.services.tenant_resolver.decode_access_token",
        lambda _token: {"tenant_id": 9, "role": "admin"},
    )

    tenant_id = TenantResolver.resolve_tenant_id_from_request(request)

    assert tenant_id == 9


def test_resolve_tenant_id_falls_back_to_state_tenant():
    request = _build_request("/api/dashboard/overview")
    request.state.tenant = SimpleNamespace(id=9)

    tenant_id = TenantResolver.resolve_tenant_id_from_request(request)

    assert tenant_id == 9


def test_extract_subdomain_accepts_base_domain_with_scheme(monkeypatch):
    monkeypatch.setattr("app.services.tenant_resolver.PUBLIC_BASE_DOMAIN", "https://servicedelivery.com.br")

    subdomain = TenantResolver.extract_subdomain("tempero.servicedelivery.com.br")

    assert subdomain == "tempero"


def test_extract_subdomain_accepts_base_domain_with_wildcard_and_leading_dot(monkeypatch):
    monkeypatch.setattr("app.services.tenant_resolver.PUBLIC_BASE_DOMAIN", "*.servicedelivery.com.br")

    wildcard_subdomain = TenantResolver.extract_subdomain("tempero.servicedelivery.com.br")

    monkeypatch.setattr("app.services.tenant_resolver.PUBLIC_BASE_DOMAIN", ".servicedelivery.com.br")

    dotted_subdomain = TenantResolver.extract_subdomain("tempero.servicedelivery.com.br")

    assert wildcard_subdomain == "tempero"
    assert dotted_subdomain == "tempero"


def test_extract_subdomain_from_request_prioritizes_forwarded_host(monkeypatch):
    monkeypatch.setenv("BASE_DOMAIN", "servicedelivery.com.br")
    request = _build_request(
        "/api/dashboard/overview",
        headers={
            "host": "servicedelivery.com.br",
            "x-forwarded-host": "tempero.servicedelivery.com.br:443",
        },
    )

    subdomain = TenantResolver.extract_subdomain_from_request(request)

    assert subdomain == "tempero"


def test_extract_subdomain_from_request_supports_mobile_like_prefixes(monkeypatch):
    monkeypatch.setenv("BASE_DOMAIN", "servicedelivery.com.br")

    mobile_host_request = _build_request(
        "/api/dashboard/overview",
        headers={"host": "m.tempero.servicedelivery.com.br"},
    )
    www_host_request = _build_request(
        "/api/dashboard/overview",
        headers={"host": "www.tempero.servicedelivery.com.br"},
    )

    mobile_subdomain = TenantResolver.extract_subdomain_from_request(mobile_host_request)
    www_subdomain = TenantResolver.extract_subdomain_from_request(www_host_request)

    assert mobile_subdomain == "tempero"
    assert www_subdomain == "tempero"


def test_extract_subdomain_supports_mobile_like_prefixes(monkeypatch):
    monkeypatch.setenv("BASE_DOMAIN", "servicedelivery.com.br")

    assert TenantResolver.extract_subdomain("m.tempero.servicedelivery.com.br") == "tempero"
    assert TenantResolver.extract_subdomain("www.tempero.servicedelivery.com.br") == "tempero"


def test_extract_subdomain_raises_for_invalid_host(monkeypatch):
    monkeypatch.setenv("BASE_DOMAIN", "servicedelivery.com.br")

    with pytest.raises(TenantResolutionError):
        TenantResolver.extract_subdomain("tempero.outrabase.com")


class _FakeQuery:
    def __init__(self, tenant):
        self._tenant = tenant

    def filter(self, *_args, **_kwargs):
        return self

    def first(self):
        return self._tenant


class _FakeDB:
    def __init__(self, tenant):
        self._tenant = tenant

    def query(self, _model):
        return _FakeQuery(self._tenant)


def test_resolve_tenant_from_request_prioritizes_x_tenant_id_slug(monkeypatch):
    request = _build_request(
        "/api/delivery/auth/login",
        headers={
            "x-tenant-id": "tempero",
            "x-forwarded-host": "service-delivery-backend-production.up.railway.app",
            "host": "service-delivery-backend-production.up.railway.app",
        },
    )

    tenant = SimpleNamespace(id=13, slug="tempero")
    db = _FakeDB(tenant)

    resolved = TenantResolver.resolve_tenant_from_request(db, request)

    assert resolved == tenant


def test_resolve_tenant_from_request_falls_back_to_host_priority(monkeypatch):
    monkeypatch.setenv("BASE_DOMAIN", "servicedelivery.com.br")
    request = _build_request(
        "/api/delivery/auth/login",
        headers={
            "x-forwarded-host": "www.tempero.servicedelivery.com.br",
            "host": "tempero.servicedelivery.com.br",
        },
    )

    tenant = SimpleNamespace(id=13, slug="tempero")
    db = _FakeDB(tenant)

    resolved = TenantResolver.resolve_tenant_from_request(db, request)

    assert resolved == tenant
