from __future__ import annotations

import json
from decimal import Decimal
import logging
import re
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field, model_validator
from sqlalchemy import func
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from app.core.database import get_db
from app.models.customer import Customer
from app.models.customer_address import CustomerAddress
from app.models.customer_points import CustomerPoints
from app.models.coupon import Coupon, CouponRedemption
from app.models.menu_category import MenuCategory
from app.models.menu_item import MenuItem
from app.models.modifier_option import ModifierOption
from app.models.modifier_group import ModifierGroup
from app.models.order import Order
from app.models.marketing import CustomerPointTransaction
from app.models.tenant import Tenant
from app.models.tenant_public_settings import TenantPublicSettings
from app.services.finance import maybe_create_payment_for_order
from app.services.order_events import emit_order_created
from app.services.orders import _build_items_text, create_order_items, get_next_daily_order_number
from app.services.geocoding_service import geocode_address
from app.services.product_configuration import list_modifier_groups_for_product
from app.services.loyalty import calculate_order_points, resolve_reais_por_ponto
from app.services.tenant_resolver import TenantResolver
from utils.slug import normalize_slug

logger = logging.getLogger(__name__)
PUBLIC_TENANT_PREFIX = "[PUBLIC_TENANT]"
PUBLIC_MENU_PREFIX = "[PUBLIC_MENU]"

router = APIRouter(prefix="/public", tags=["public-menu"])


def build_full_address(order: PublicOrderPayload) -> str:
    parts: list[str] = []
    delivery_address = order.delivery_address or {}

    if order.street:
        parts.append(order.street.strip())

    if order.number:
        parts.append(str(order.number).strip())

    if order.complement:
        parts.append(order.complement.strip())

    if order.neighborhood:
        parts.append(order.neighborhood.strip())

    if order.city:
        parts.append(order.city.strip())

    state = (
        (getattr(order, "state", "") or "").strip()
        or str(delivery_address.get("state") or "").strip()
    )
    if state:
        parts.append(state)

    zip_code = str(delivery_address.get("zip") or "").strip()
    if zip_code:
        parts.append(zip_code)

    parts.append("Brasil")

    return ", ".join(parts)


class PublicStoreResponse(BaseModel):
    id: int
    slug: str
    name: str
    custom_domain: Optional[str]
    manual_open_status: bool = True
    estimated_prep_time: Optional[str]
    delivery_fee: float = 0.0


class PublicMenuItem(BaseModel):
    id: int
    category_id: Optional[int]
    name: str
    description: Optional[str]
    price_cents: int
    image_url: Optional[str]
    modifier_groups: list["PublicModifierGroupSchema"] = Field(default_factory=list)


class PublicModifierOptionSchema(BaseModel):
    id: int
    name: str
    price_delta: float


class PublicModifierGroupSchema(BaseModel):
    id: int
    name: str
    required: bool
    min_selection: int
    max_selection: int
    options: list[PublicModifierOptionSchema] = Field(default_factory=list)


class PublicMenuCategory(BaseModel):
    id: int
    name: str
    sort_order: int
    items: list[PublicMenuItem]


class PublicSettingsResponse(BaseModel):
    cover_image_url: Optional[str]
    cover_video_url: Optional[str]
    logo_url: Optional[str]
    theme: Optional[str]
    primary_color: Optional[str]


class PublicMenuResponse(BaseModel):
    tenant: PublicStoreResponse
    public_settings: Optional[PublicSettingsResponse]
    tenant_id: int
    slug: str
    categories: list[PublicMenuCategory]
    items_without_category: list[PublicMenuItem]

class PublicOrderItem(BaseModel):
    item_id: int
    quantity: int = Field(..., gt=0)
    selected_modifiers: Optional[list["PublicSelectedModifier"]] = []


class PublicSelectedModifier(BaseModel):
    group_id: int
    option_id: int
    quantity: int = Field(default=1, gt=0)


class PublicOrderProductItem(BaseModel):
    product_id: int
    quantity: int = Field(..., gt=0)
    selected_modifiers: list[PublicSelectedModifier] = Field(default_factory=list)


class PublicOrderPayload(BaseModel):
    store_id: int | None = None
    customer_name: str = ""
    customer_phone: str = ""
    customer_email: str = ""
    address: str = ""
    notes: str = ""
    delivery_type: str = ""
    payment_method: str = ""
    payment_change_for: str = ""
    change_for: str = ""
    order_note: str = ""
    delivery_address: dict = Field(default_factory=dict)
    order_type: str = ""
    street: str = ""
    number: str = ""
    complement: str = ""
    neighborhood: str = ""
    city: str = ""
    state: str = ""
    reference: str = ""
    table_number: str = ""
    command_number: str = ""
    channel: str = ""
    coupon_code: str = ""
    redeem_points: int = 0
    items: list[PublicOrderItem] = Field(default_factory=list)
    products: list[PublicOrderProductItem] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_delivery_address_zip(self):
        normalized_order_type = (self.order_type or "").strip().lower()
        if normalized_order_type != "delivery":
            return self

        delivery_address = self.delivery_address or {}
        resolved_zip = str(delivery_address.get("zip") or delivery_address.get("cep") or "").strip()
        if not resolved_zip:
            raise ValueError("ZIP code is required for delivery orders")
        return self

class PublicResolvedModifier(BaseModel):
    group_name: str
    option_name: str


class PublicOrderResponseItem(BaseModel):
    item_name: str
    quantity: int
    modifiers: list[PublicResolvedModifier] = Field(default_factory=list)


class PublicOrderCreateResponse(BaseModel):
    order_id: int
    daily_order_number: int | None = None
    points_earned: int = 0
    customer_id: int | None = None
    tracking_token: str
    status: str
    estimated_time: int
    subtotal: float = 0
    delivery_fee: float = 0
    total: float
    order_type: str
    payment_method: str | None = None
    street: str | None = None
    number: str | None = None
    complement: str | None = None
    neighborhood: str | None = None
    city: str | None = None
    reference: str | None = None
    items: list[PublicOrderResponseItem] = Field(default_factory=list)


def _resolve_public_order_number(order: Order) -> int:
    return int(order.daily_order_number or order.id)


def _resolve_estimated_time_minutes(tenant: Tenant) -> int:
    raw_value = getattr(tenant, "estimated_prep_time", None)
    if raw_value is None:
        return 30

    if isinstance(raw_value, int):
        return raw_value

    match = re.search(r"\d+", str(raw_value))
    if not match:
        return 30

    return int(match.group(0))


def _resolve_order_type(order_type: str, delivery_type: str) -> str:
    normalized = (order_type or "").strip().lower()
    if normalized in {"delivery", "pickup", "table"}:
        return normalized

    delivery = (delivery_type or "").strip().lower()
    if delivery in {"retirada", "pickup"}:
        return "pickup"
    if delivery in {"mesa", "table"}:
        return "table"
    return "delivery"


def _resolve_delivery_state(payload: PublicOrderPayload, delivery_address: dict) -> str:
    raw_state = (
        str(payload.state or "").strip()
        or str(delivery_address.get("state") or "").strip()
        or str(delivery_address.get("uf") or "").strip()
        or "SP"
    )
    return raw_state[:2].upper()


def _validate_delivery_payload(payload: PublicOrderPayload, delivery_address: dict) -> str:
    if _resolve_order_type(payload.order_type, payload.delivery_type) != "delivery":
        return ""

    state_value = _resolve_delivery_state(payload, delivery_address)
    if not state_value:
        raise HTTPException(status_code=422, detail="Estado é obrigatório")
    return state_value


def _resolve_delivery_zip(delivery_address: dict) -> str:
    return str(delivery_address.get("zip") or delivery_address.get("cep") or "").strip()


def _validate_delivery_zip(payload: PublicOrderPayload, delivery_address: dict) -> str:
    if _resolve_order_type(payload.order_type, payload.delivery_type) != "delivery":
        return ""

    zip_code = _resolve_delivery_zip(delivery_address)
    if not zip_code:
        raise HTTPException(
            status_code=400,
            detail="ZIP code is required for delivery orders",
        )
    return zip_code



def resolve_tenant_from_host(db: Session, host: str) -> Tenant:
    normalized_host = TenantResolver.normalize_host(host)
    if normalized_host:
        tenant_by_custom_domain = (
            db.query(Tenant)
            .filter(func.lower(Tenant.custom_domain) == normalized_host)
            .first()
        )
        if tenant_by_custom_domain:
            return tenant_by_custom_domain

    return TenantResolver.resolve_from_host(db, normalized_host)


def resolve_tenant_from_slug(db: Session, slug: str) -> Tenant:
    normalized_slug = normalize_slug(slug)
    if not normalized_slug:
        raise HTTPException(status_code=400, detail="Slug inválido")

    tenant = db.query(Tenant).filter(Tenant.slug == normalized_slug).first()
    if not tenant:
        raise HTTPException(status_code=404, detail="Loja não encontrada")
    return tenant


def _resolve_host_from_request(request: Request) -> str:
    return request.headers.get("x-forwarded-host") or request.headers.get("host") or ""


def _resolve_base_url(request: Request) -> str:
    forwarded_proto = request.headers.get("x-forwarded-proto")
    forwarded_host = request.headers.get("x-forwarded-host")

    if forwarded_host:
        scheme = forwarded_proto or request.url.scheme
        return f"{scheme}://{forwarded_host}"

    return str(request.base_url).rstrip("/")


def _resolve_image_url(base_url: str, image_url: Optional[str]) -> Optional[str]:
    if not image_url:
        return None
    if image_url.startswith("http://") or image_url.startswith("https://"):
        return image_url
    base = base_url.rstrip("/")
    if image_url.startswith("/"):
        return f"{base}{image_url}"
    return f"{base}/{image_url}"


def _build_menu_payload(
    db: Session,
    tenant: Tenant,
    base_url: str,
) -> PublicMenuResponse:
    settings = (
        db.query(TenantPublicSettings)
        .filter(TenantPublicSettings.tenant_id == tenant.id)
        .first()
    )
    categories = (
        db.query(MenuCategory)
        .filter(MenuCategory.tenant_id == tenant.id, MenuCategory.active.is_(True))
        .order_by(MenuCategory.sort_order.asc(), MenuCategory.name.asc())
        .all()
    )
    items = (
        db.query(MenuItem)
        .filter(MenuItem.tenant_id == tenant.id, MenuItem.active.is_(True))
        .order_by(MenuItem.name.asc())
        .all()
    )

    items_by_category: dict[int | None, list[PublicMenuItem]] = {}
    for item in items:
        entry = PublicMenuItem(
            id=item.id,
            category_id=item.category_id,
            name=item.name,
            description=item.description,
            price_cents=item.price_cents,
            image_url=_resolve_image_url(base_url, item.image_url),
            modifier_groups=list_modifier_groups_for_product(
                db,
                tenant_id=tenant.id,
                product_id=item.id,
                only_active_options=True,
            ),
        )
        items_by_category.setdefault(item.category_id, []).append(entry)

    category_payload = [
        PublicMenuCategory(
            id=category.id,
            name=category.name,
            sort_order=category.sort_order,
            items=items_by_category.get(category.id, []),
        )
        for category in categories
    ]
    uncategorized = items_by_category.get(None, [])

    logger.info(
        "%s tenant_id=%s slug=%s categories=%s items=%s",
        PUBLIC_MENU_PREFIX,
        tenant.id,
        tenant.slug,
        len(category_payload),
        len(items),
    )

    public_settings = None
    if settings:
        public_settings = PublicSettingsResponse(
            cover_image_url=_resolve_image_url(base_url, settings.cover_image_url),
            cover_video_url=_resolve_image_url(base_url, settings.cover_video_url),
            logo_url=_resolve_image_url(base_url, settings.logo_url),
            theme=settings.theme,
            primary_color=settings.primary_color,
        )

    return PublicMenuResponse(
        tenant=PublicStoreResponse(
            id=tenant.id,
            slug=tenant.slug,
            name=tenant.business_name,
            custom_domain=tenant.custom_domain,
            manual_open_status=(getattr(tenant, "manual_open_status", True) if getattr(tenant, "manual_open_status", None) is not None else True),
            estimated_prep_time=getattr(tenant, "estimated_prep_time", None),
            delivery_fee=float(getattr(tenant, "delivery_fee", 0) or 0),
        ),
        public_settings=public_settings,
        tenant_id=tenant.id,
        slug=tenant.slug,
        categories=category_payload,
        items_without_category=uncategorized,
    )


def _normalize_phone(phone: str) -> str:
    return re.sub(r"\D", "", phone or "")


def _get_or_create_customer(db: Session, tenant_id: int, customer_name: str, customer_phone: str, customer_email: str = "") -> Customer | None:
    normalized_phone = _normalize_phone(customer_phone)
    if not normalized_phone:
        return None

    customer = (
        db.query(Customer)
        .filter(Customer.tenant_id == tenant_id, Customer.phone == normalized_phone)
        .order_by(Customer.id.desc())
        .first()
    )
    if customer:
        normalized_name = (customer_name or "").strip()
        normalized_email = (customer_email or "").strip()
        if normalized_name and customer.name != normalized_name:
            customer.name = normalized_name
        if normalized_email:
            customer.email = normalized_email
        db.flush()
        return customer

    customer = Customer(
        tenant_id=tenant_id,
        phone=normalized_phone,
        name=(customer_name or "").strip() or "Cliente",
        email=(customer_email or "").strip() or None,
    )
    db.add(customer)
    db.flush()
    return customer

async def _create_order_for_tenant(
    db: Session,
    tenant: Tenant,
    payload: PublicOrderPayload,
    item_modifiers_by_index: Optional[dict[int, list[PublicSelectedModifier]]] = None,
) -> PublicOrderCreateResponse:
    current_store = tenant
    if not payload.items:
        payload.items = [
            PublicOrderItem(
                item_id=entry.product_id,
                quantity=entry.quantity,
                selected_modifiers=entry.selected_modifiers,
            )
            for entry in payload.products
        ]

    if not payload.items and not payload.products:
        raise HTTPException(status_code=400, detail="Carrinho vazio")

    item_ids = [entry.item_id for entry in payload.items]
    menu_items = (
        db.query(MenuItem)
        .filter(
            MenuItem.tenant_id == tenant.id,
            MenuItem.active.is_(True),
            MenuItem.id.in_(item_ids),
        )
        .all()
    )
    menu_item_map = {item.id: item for item in menu_items}

    items_structured: list[dict] = []
    total_cents = 0
    product_entries = payload.products or [
        PublicOrderProductItem(
            product_id=entry.item_id,
            quantity=entry.quantity,
            selected_modifiers=entry.selected_modifiers or (item_modifiers_by_index or {}).get(index, []),
        )
        for index, entry in enumerate(payload.items)
    ]

    for entry in product_entries:
        logger.info(f"Selected modifiers received: {entry.selected_modifiers}")
        menu_item = menu_item_map.get(entry.product_id)
        if not menu_item:
            raise HTTPException(status_code=400, detail=f"Item inválido: {entry.product_id}")

        selected_modifiers = entry.selected_modifiers or []
        modifier_groups = (
            db.query(ModifierGroup)
            .filter(
                ModifierGroup.tenant_id == tenant.id,
                ModifierGroup.product_id == menu_item.id,
                ModifierGroup.active.is_(True),
            )
            .all()
        )
        groups_by_id = {group.id: group for group in modifier_groups}
        options = (
            db.query(ModifierOption)
            .join(ModifierGroup, ModifierGroup.id == ModifierOption.group_id)
            .filter(
                ModifierOption.group_id.in_(groups_by_id.keys()) if groups_by_id else False,
                ModifierGroup.tenant_id == tenant.id,
                ModifierOption.is_active.is_(True),
            )
            .all()
            if groups_by_id
            else []
        )
        option_by_id = {option.id: option for option in options}
        selected_by_group: dict[int, list[ModifierOption]] = {}
        for selected in selected_modifiers:
            group = groups_by_id.get(selected.group_id)
            option = option_by_id.get(selected.option_id)
            if not group or not option or int(option.group_id) != int(group.id) or not option.is_active:
                raise HTTPException(status_code=400, detail="Configuração de modificador inválida")
            selected_by_group.setdefault(group.id, []).append(option)

        for group in modifier_groups:
            chosen = selected_by_group.get(group.id, [])
            chosen_len = len(chosen)
            if group.required and chosen_len == 0:
                raise HTTPException(status_code=400, detail=f"Grupo obrigatório sem seleção: {group.name}")
            if chosen_len < int(group.min_selection or 0):
                raise HTTPException(status_code=400, detail=f"Mínimo não atendido para grupo: {group.name}")
            if chosen_len > int(group.max_selection or 1):
                raise HTTPException(status_code=400, detail=f"Máximo excedido para grupo: {group.name}")

        qty = int(entry.quantity)
        modifiers_payload = []
        modifiers_total_cents = 0
        for selected in selected_modifiers:
            group = groups_by_id[selected.group_id]
            option = option_by_id[selected.option_id]
            price_delta_cents = int(round(float(option.price_delta or 0) * 100))
            modifiers_payload.append(
                {
                    "group_id": selected.group_id,
                    "option_id": selected.option_id,
                    "group_name": group.name,
                    "option_name": option.name,
                    "name": option.name,
                    "price_cents": price_delta_cents,
                }
            )
            modifiers_total_cents += price_delta_cents

        subtotal = (menu_item.price_cents + modifiers_total_cents) * qty
        total_cents += subtotal
        items_structured.append(
            {
                "menu_item_id": menu_item.id,
                "name": menu_item.name,
                "quantity": qty,
                "unit_price_cents": menu_item.price_cents,
                "modifiers": modifiers_payload,
                "selected_modifiers": [
                    {"group_id": selected.group_id, "option_id": selected.option_id}
                    for selected in selected_modifiers
                ],
                "modifiers_total_cents": modifiers_total_cents,
                "subtotal_cents": subtotal,
            }
        )

    for entry in payload.items:
        menu_item = menu_item_map.get(entry.item_id)
        if menu_item and not any(item["menu_item_id"] == menu_item.id for item in items_structured):
            qty = int(entry.quantity)
            subtotal = menu_item.price_cents * qty
            total_cents += subtotal
            items_structured.append(
                {
                    "menu_item_id": menu_item.id,
                    "name": menu_item.name,
                    "quantity": qty,
                    "unit_price_cents": menu_item.price_cents,
                    "subtotal_cents": subtotal,
                }
            )

    customer = _get_or_create_customer(
        db=db,
        tenant_id=tenant.id,
        customer_name=payload.customer_name,
        customer_phone=payload.customer_phone,
        customer_email=payload.customer_email,
    )

    calculated_subtotal_cents = total_cents
    delivery_address = payload.delivery_address or {}
    validated_state = _validate_delivery_payload(payload, delivery_address)

    full_address = build_full_address(payload)
    lat, lng = None, None

    fallback_endereco = (payload.address or "").strip() or full_address

    resolved_order_type = _resolve_order_type(payload.order_type, payload.delivery_type)
    resolved_zip = _validate_delivery_zip(payload, delivery_address)

    if resolved_order_type == "delivery":
        delivery_fee_decimal = getattr(tenant, "delivery_fee", 0) or 0
    else:
        delivery_fee_decimal = 0

    delivery_fee_cents = int(round(float(delivery_fee_decimal) * 100))
    calculated_total_cents = calculated_subtotal_cents + delivery_fee_cents

    applied_coupon = None
    discount_amount_cents = 0
    coupon_code = (payload.coupon_code or "").strip().upper()
    if coupon_code:
        coupon = (
            db.query(Coupon)
            .filter(Coupon.tenant_id == tenant.id, func.upper(Coupon.code) == coupon_code, Coupon.active.is_(True))
            .first()
        )
        if coupon and (coupon.min_order_value is None or Decimal(str(calculated_total_cents / 100)) >= Decimal(str(coupon.min_order_value))):
            if coupon.discount_type == "percentage":
                discount_amount_cents += int(round(calculated_total_cents * (float(coupon.discount_value or 0) / 100)))
            elif coupon.discount_type == "fixed":
                discount_amount_cents += int(round(float(coupon.discount_value or 0) * 100))
            applied_coupon = coupon

    redeem_points = max(0, int(payload.redeem_points or 0))
    if customer and redeem_points > 0:
        points_row = (
            db.query(CustomerPoints)
            .filter(CustomerPoints.tenant_id == tenant.id, CustomerPoints.customer_id == customer.id)
            .first()
        )
        if points_row is not None and int(points_row.available_points or 0) > 0:
            used_points = min(redeem_points, int(points_row.available_points or 0))
            discount_amount_cents += used_points
            points_row.available_points = int(points_row.available_points or 0) - used_points
            db.add(
                CustomerPointTransaction(
                    tenant_id=tenant.id,
                    customer_id=customer.id,
                    points_delta=-used_points,
                    reason="redeem_checkout",
                )
            )

    if discount_amount_cents > calculated_total_cents:
        discount_amount_cents = calculated_total_cents
    calculated_total_cents -= discount_amount_cents

    normalized_delivery_address: dict | None = None
    if resolved_order_type == "delivery":
        normalized_delivery_address = {
            "zip": resolved_zip,
            "cep": resolved_zip,
            "street": (payload.street or delivery_address.get("street") or "").strip(),
            "number": (payload.number or delivery_address.get("number") or "").strip(),
            "complement": (payload.complement or delivery_address.get("complement") or "").strip(),
            "neighborhood": (
                payload.neighborhood
                or delivery_address.get("neighborhood")
                or delivery_address.get("district")
                or ""
            ).strip(),
            "city": (payload.city or delivery_address.get("city") or "").strip(),
            "state": validated_state,
            "reference": (payload.reference or delivery_address.get("reference") or "").strip(),
        }

    normalized_customer_phone = _normalize_phone(payload.customer_phone or "")

    order = Order(
        tenant_id=current_store.id,
        daily_order_number=get_next_daily_order_number(db, current_store.id),
        cliente_nome=(payload.customer_name or "").strip(),
        cliente_telefone=normalized_customer_phone,
        itens=_build_items_text(items_structured) or "(não informado)",
        items_json=json.dumps(items_structured, ensure_ascii=False),
        endereco=fallback_endereco,
        customer_lat=None,
        customer_lng=None,
        observacao=(payload.notes or payload.order_note or "").strip(),
        tipo_entrega=(payload.delivery_type or "").upper(),
        forma_pagamento=(payload.payment_method or "").upper(),
        customer_id=(customer.id if customer else None),
        customer_name=(payload.customer_name or "").strip() or (customer.name if customer else None),
        customer_phone=normalized_customer_phone or (customer.phone if customer else None),
        delivery_address_json=normalized_delivery_address,
        payment_method=(payload.payment_method or "").strip().lower() or None,
        payment_change_for=(payload.payment_change_for or payload.change_for or None),
        order_type=resolved_order_type,
        street=(payload.street or delivery_address.get("street") or "").strip() or None,
        number=(payload.number or delivery_address.get("number") or "").strip() or None,
        complement=(payload.complement or delivery_address.get("complement") or "").strip() or None,
        neighborhood=(payload.neighborhood or delivery_address.get("neighborhood") or delivery_address.get("district") or "").strip() or None,
        city=(payload.city or delivery_address.get("city") or "").strip() or None,
        reference=(payload.reference or delivery_address.get("reference") or "").strip() or None,
        table_number=(payload.table_number or "").strip() or None,
        command_number=(payload.command_number or "").strip() or None,
        change_for=(payload.payment_change_for or payload.change_for or None),
        channel=(payload.channel or "public_menu").strip() or None,
        order_note=(payload.order_note or payload.notes or "").strip() or None,
        status="pending",
        subtotal=float(calculated_subtotal_cents) / 100,
        delivery_fee=float(delivery_fee_decimal or 0),
        valor_total=calculated_total_cents,
        total_cents=calculated_total_cents,
        coupon_id=applied_coupon.id if applied_coupon else None,
        discount_amount=Decimal(str(discount_amount_cents / 100)) if discount_amount_cents > 0 else None,
    )

    db.add(order)
    try:
        if validated_state:
            delivery_payload = dict(order.delivery_address_json or {})
            delivery_payload["state"] = validated_state
            if resolved_zip:
                delivery_payload["zip"] = resolved_zip
                delivery_payload["cep"] = resolved_zip
            order.delivery_address_json = delivery_payload

        db.flush()
        if applied_coupon is not None:
            applied_coupon.uses_count = int(applied_coupon.uses_count or 0) + 1
            db.add(CouponRedemption(coupon_id=applied_coupon.id, customer_id=customer.id if customer else None, order_id=order.id))
        logger.info(
            "geocoding_request",
            extra={
                "order_id": order.id,
                "address": full_address,
            },
        )
        if full_address.strip() != "Brasil":
            try:
                lat, lng = await geocode_address(full_address)
            except Exception:
                logger.warning(
                    "geocoding_failed",
                    extra={
                        "order_id": order.id,
                    },
                )
                lat, lng = None, None
            else:
                if lat is None or lng is None:
                    logger.warning(
                        "geocoding_failed",
                        extra={
                            "order_id": order.id,
                        },
                    )
        order.customer_lat = lat
        order.customer_lng = lng
        order.delivery_lat = lat
        order.delivery_lng = lng
        if lat is not None and lng is not None:
            delivery_payload = dict(order.delivery_address_json or {})
            delivery_payload["coordinates"] = {"lat": lat, "lng": lng}
            if resolved_zip:
                delivery_payload["zip"] = resolved_zip
                delivery_payload["cep"] = resolved_zip
            order.delivery_address_json = delivery_payload

        should_create_customer_address = (
            customer
            and order.order_type == "delivery"
            and order.street
            and order.number
            and order.neighborhood
            and order.city
        )
        if should_create_customer_address:
            delivery_address = dict(order.delivery_address_json or {})
            state_value = _resolve_delivery_state(payload, delivery_address)
            cep_value = str(delivery_address.get("zip") or delivery_address.get("cep") or "").strip()
            if not cep_value:
                raise HTTPException(
                    status_code=400,
                    detail="ZIP code is required for delivery orders",
                )
            has_any_address = (
                db.query(CustomerAddress.id)
                .filter(CustomerAddress.customer_id == customer.id)
                .first()
                is not None
            )
            customer_address = CustomerAddress(
                customer_id=customer.id,
                zip=cep_value,
                cep=cep_value,
                street=order.street,
                number=order.number,
                complement=order.complement,
                district=order.neighborhood,
                neighborhood=order.neighborhood,
                city=order.city,
                state=state_value,
                is_default=not has_any_address,
            )
            db.add(customer_address)

        reais_por_ponto = resolve_reais_por_ponto(tenant)
        points_earned = 0
        if customer and bool(getattr(tenant, "points_enabled", True)):
            points_earned = calculate_order_points(order.total_cents or order.valor_total, reais_por_ponto)
            if points_earned > 0:
                points_row = (
                    db.query(CustomerPoints)
                    .filter(CustomerPoints.tenant_id == tenant.id, CustomerPoints.customer_id == customer.id)
                    .first()
                )
                if points_row is None:
                    points_row = CustomerPoints(
                        tenant_id=tenant.id,
                        customer_id=customer.id,
                        available_points=0,
                        lifetime_points=0,
                    )
                    db.add(points_row)
                    db.flush()
                points_row.available_points = int(points_row.available_points or 0) + points_earned
                points_row.lifetime_points = int(points_row.lifetime_points or 0) + points_earned
                db.add(
                    CustomerPointTransaction(
                        tenant_id=tenant.id,
                        customer_id=customer.id,
                        order_id=order.id,
                        points_delta=points_earned,
                        reason="order_created",
                    )
                )

        create_order_items(db, tenant_id=tenant.id, order_id=order.id, items_structured=items_structured)
        try:
            with db.begin_nested():
                maybe_create_payment_for_order(db, order, payload.payment_method)
        except Exception:
            logger.exception(
                "order_payment_creation_failed",
                extra={"order_id": order.id, "tenant_id": tenant.id},
            )
        db.commit()
        db.refresh(order)
        emit_order_created(order)
    except IntegrityError:
        db.rollback()
        raise
    except Exception:
        db.rollback()
        raise

    print("ORDER SAVED:", order.id, "STORE:", current_store.id)

    response_items = [
        PublicOrderResponseItem(
            item_name=str(entry.get("name", "") or ""),
            quantity=int(entry.get("quantity", 0) or 0),
            modifiers=[
                PublicResolvedModifier(
                    group_name=str(modifier.get("group_name", "") or "").strip(),
                    option_name=str(modifier.get("option_name", modifier.get("name", "")) or "").strip(),
                )
                for modifier in (entry.get("modifiers") or [])
                if str(modifier.get("option_name", modifier.get("name", "")) or "").strip()
            ],
        )
        for entry in items_structured
    ]

    return PublicOrderCreateResponse(
        order_id=_resolve_public_order_number(order),
        daily_order_number=order.daily_order_number,
        points_earned=points_earned,
        customer_id=order.customer_id,
        tracking_token=order.tracking_token,
        status=order.status,
        estimated_time=_resolve_estimated_time_minutes(tenant),
        subtotal=float(order.subtotal or 0),
        delivery_fee=float(order.delivery_fee or 0),
        total=float(order.total_cents or order.valor_total or 0),
        order_type=order.order_type,
        payment_method=order.payment_method,
        street=order.street,
        number=order.number,
        complement=order.complement,
        neighborhood=order.neighborhood,
        city=order.city,
        reference=order.reference,
        items=response_items,
    )


def _get_public_tenant_by_host_payload(request: Request, db: Session) -> PublicStoreResponse:
    host = _resolve_host_from_request(request)
    tenant = getattr(request.state, "tenant", None) or resolve_tenant_from_host(db, host)
    logger.info(
        "%s resolved host=%s tenant_id=%s slug=%s",
        PUBLIC_TENANT_PREFIX,
        host,
        tenant.id,
        tenant.slug,
    )
    return PublicStoreResponse(
        id=tenant.id,
        slug=tenant.slug,
        name=tenant.business_name,
        custom_domain=tenant.custom_domain,
        manual_open_status=(getattr(tenant, "manual_open_status", True) if getattr(tenant, "manual_open_status", None) is not None else True),
        estimated_prep_time=getattr(tenant, "estimated_prep_time", None),
        delivery_fee=float(getattr(tenant, "delivery_fee", 0) or 0),
    )


def _get_public_menu_payload(
    request: Request,
    db: Session,
    slug: Optional[str] = None,
) -> PublicMenuResponse:
    if slug:
        tenant = resolve_tenant_from_slug(db, slug)
        logger.info(
            "%s mode=slug slug=%s tenant_id=%s",
            PUBLIC_MENU_PREFIX,
            tenant.slug,
            tenant.id,
        )
    else:
        host = _resolve_host_from_request(request)
        tenant = getattr(request.state, "tenant", None) or resolve_tenant_from_host(db, host)
        logger.info(
            "%s mode=host host=%s tenant_id=%s slug=%s",
            PUBLIC_MENU_PREFIX,
            host,
            tenant.id,
            tenant.slug,
        )

    return _build_menu_payload(db, tenant, _resolve_base_url(request))


async def _create_public_order_payload(
    request: Request,
    payload: PublicOrderPayload,
    db: Session,
    raw_payload: Optional[dict] = None,
) -> dict:
    host = _resolve_host_from_request(request)
    tenant = getattr(request.state, "tenant", None) or resolve_tenant_from_host(db, host)
    logger.info(
        "%s resolved host=%s tenant_id=%s slug=%s",
        PUBLIC_TENANT_PREFIX,
        host,
        tenant.id,
        tenant.slug,
    )
    item_modifiers_by_index: dict[int, list[PublicSelectedModifier]] = {}
    raw_items = (raw_payload or {}).get("items") if isinstance(raw_payload, dict) else None
    if isinstance(raw_items, list):
        for index, raw_item in enumerate(raw_items):
            if not isinstance(raw_item, dict):
                continue
            raw_modifiers = raw_item.get("selected_modifiers")
            if not isinstance(raw_modifiers, list):
                continue
            normalized_modifiers: list[PublicSelectedModifier] = []
            for raw_modifier in raw_modifiers:
                if not isinstance(raw_modifier, dict):
                    continue
                group_id = raw_modifier.get("group_id")
                option_id = raw_modifier.get("option_id")
                if isinstance(group_id, int) and isinstance(option_id, int):
                    normalized_modifiers.append(PublicSelectedModifier(group_id=group_id, option_id=option_id))
            if normalized_modifiers:
                item_modifiers_by_index[index] = normalized_modifiers

    return await _create_order_for_tenant(
        db,
        tenant,
        payload,
        item_modifiers_by_index=item_modifiers_by_index,
    )


@router.get("/tenant/by-host", response_model=PublicStoreResponse)
def get_public_tenant_by_host(request: Request, db: Session = Depends(get_db)):
    return _get_public_tenant_by_host_payload(request, db)


@router.get("/menu", response_model=PublicMenuResponse)
def get_public_menu(
    request: Request,
    slug: Optional[str] = Query(default=None),
    db: Session = Depends(get_db),
):
    return _get_public_menu_payload(request, db, slug=slug)


@router.post("/orders", response_model=PublicOrderCreateResponse, summary="Create Public Order", operation_id="create_public_order_public_orders_post")
async def create_public_order(
    request: Request,
    payload: PublicOrderPayload,
    db: Session = Depends(get_db),
):
    raw_payload = await request.json()
    return await _create_public_order_payload(request, payload, db, raw_payload=raw_payload)
