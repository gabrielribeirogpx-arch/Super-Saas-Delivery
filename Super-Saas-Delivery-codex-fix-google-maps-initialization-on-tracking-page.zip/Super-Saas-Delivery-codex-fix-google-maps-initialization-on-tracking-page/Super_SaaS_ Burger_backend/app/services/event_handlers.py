from __future__ import annotations

from sqlalchemy.orm import Session

from app.core.database import SessionLocal
from app.models.order import Order
from app.services.customer_stats import update_customer_stats_for_order
from app.realtime.publisher import publish_delivery_assignment_event
from app.services.event_bus import event_bus
from app.services.whatsapp_outbound import send_whatsapp_message


def _with_session(handler):
    def wrapper(payload: dict) -> None:
        db: Session = SessionLocal()
        try:
            handler(db, payload)
        finally:
            db.close()

    return wrapper


@_with_session
def handle_order_created(db: Session, payload: dict) -> None:
    send_whatsapp_message(
        db,
        tenant_id=payload["tenant_id"],
        phone=payload["customer_phone"],
        template="order_confirmed",
        variables={
            "customer_name": payload.get("customer_name") or "Cliente",
            "order_number": payload.get("order_number") or payload["order_id"],
            "total_cents": payload.get("total_cents", 0),
            "estimated_time": payload.get("estimated_time", "30 min"),
        },
        order_id=payload["order_id"],
    )


@_with_session
def handle_order_status_changed(db: Session, payload: dict) -> None:
    status = payload.get("status")
    template = None
    if status in {"EM_PREPARO", "PREPARO"}:
        template = "order_in_preparation"
    elif status == "PRONTO":
        template = "order_ready"
    elif status in {"SAIU", "SAIU_PARA_ENTREGA", "OUT_FOR_DELIVERY"}:
        template = "order_out_for_delivery"
    elif status in {"ENTREGUE", "DELIVERED"}:
        template = "order_delivered"

    if not template:
        return

    send_whatsapp_message(
        db,
        tenant_id=payload["tenant_id"],
        phone=payload["customer_phone"],
        template=template,
        variables={
            "customer_name": payload.get("customer_name") or "Cliente",
            "order_number": payload.get("order_number") or payload["order_id"],
            "total_cents": payload.get("total_cents", 0),
            "estimated_time": payload.get("estimated_time", "30 min"),
        },
        order_id=payload["order_id"],
    )


@_with_session
def handle_order_delivered(db: Session, payload: dict) -> None:
    order = (
        db.query(Order)
        .filter(
            Order.id == payload["order_id"],
            Order.tenant_id == payload["tenant_id"],
        )
        .first()
    )
    if not order:
        return
    update_customer_stats_for_order(db, order)
    db.commit()




def handle_order_status_changed_delivery_stream(payload: dict) -> None:
    tenant_id = payload.get("tenant_id")
    delivery_user_id = payload.get("assigned_delivery_user_id")
    if tenant_id is None or delivery_user_id is None:
        return

    publish_delivery_assignment_event(
        tenant_id=int(tenant_id),
        order_id=payload.get("order_id"),
        delivery_user_id=int(delivery_user_id),
        payload=payload,
    )

event_bus.subscribe("order.created", handle_order_created)
event_bus.subscribe("order.status.changed", handle_order_status_changed)
event_bus.subscribe("order.delivered", handle_order_delivered)
event_bus.subscribe("order.status.changed", handle_order_status_changed_delivery_stream)
