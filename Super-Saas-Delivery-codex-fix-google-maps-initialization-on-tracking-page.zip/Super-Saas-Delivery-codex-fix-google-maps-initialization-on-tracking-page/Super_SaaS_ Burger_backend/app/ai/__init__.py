"""AI assistant module."""
