import sqlalchemy as sa
from sqlalchemy import Boolean, Column, ForeignKey, Integer, Numeric, String, Text, DateTime, func
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from app.core.database import Base
from app.services.public_tracking import default_tracking_expires_at, generate_tracking_token


class Order(Base):
    __tablename__ = "orders"

    id = Column(Integer, primary_key=True)
    daily_order_number = Column(Integer, nullable=True)

    # Multi-tenant (por enquanto fixo em 1)
    tenant_id = Column(Integer, index=True, nullable=False)

    # Identificação do cliente
    cliente_nome = Column(String, default="", nullable=False)
    cliente_telefone = Column(String, index=True, nullable=False)

    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=True)
    customer_name = Column(String(120), nullable=True)
    customer_phone = Column(String(30), nullable=True)
    delivery_address_json = Column(JSONB().with_variant(sa.JSON(), "sqlite"), nullable=True)
    payment_method = Column(String(30), nullable=True)
    payment_change_for = Column(Numeric(10, 2), nullable=True)
    order_note = Column(Text, nullable=True)
    order_type = Column(sa.Enum("delivery", "pickup", "table", name="order_type_enum", native_enum=False), default="delivery", nullable=False)
    street = Column(String(255), nullable=True)
    number = Column(String(50), nullable=True)
    complement = Column(String(255), nullable=True)
    neighborhood = Column(String(255), nullable=True)
    city = Column(String(255), nullable=True)
    reference = Column(String(255), nullable=True)
    table_number = Column(String(50), nullable=True)
    command_number = Column(String(50), nullable=True)
    change_for = Column(Numeric(10, 2), nullable=True)
    channel = Column(String(50), nullable=True)

    # Pedido
    itens = Column(Text, nullable=False)  # texto livre por enquanto
    endereco = Column(Text, default="", nullable=False)
    customer_lat = Column(sa.Float, nullable=True)
    customer_lng = Column(sa.Float, nullable=True)
    delivery_lat = Column(sa.Float, nullable=True)
    delivery_lng = Column(sa.Float, nullable=True)
    observacao = Column(Text, default="", nullable=False)
    tipo_entrega = Column(String, default="", nullable=False)   # ENTREGA / RETIRADA
    forma_pagamento = Column(String, default="", nullable=False) # PIX / CARTAO / DINHEIRO

    # opcional nesta fase (pode ficar 0/empty)
    valor_total = Column(Integer, default=0, nullable=False)  # em centavos, quando calcular
    subtotal = Column(Numeric(10, 2), nullable=False, default=0, server_default="0")
    delivery_fee = Column(Numeric(10, 2), nullable=False, default=0, server_default="0")
    total_cents = Column(Integer, default=0, nullable=False)
    items_json = Column(Text, default="", nullable=False)
    coupon_id = Column(Integer, ForeignKey("coupons.id"), nullable=True)
    discount_amount = Column(Numeric(10, 2), nullable=True)

    # Kanban
    status = Column(String, default="RECEBIDO", nullable=False)  # RECEBIDO / EM_PREPARO / PRONTO|READY / OUT_FOR_DELIVERY / DELIVERED
    production_ready_areas_json = Column(Text, default="[]", nullable=False)
    ready_at = Column(DateTime(timezone=True), nullable=True)
    start_delivery_at = Column(DateTime(timezone=True), nullable=True)
    assigned_delivery_user_id = Column(Integer, ForeignKey("admin_users.id"), nullable=True, index=True)
    tracking_token = Column(String(36), nullable=False, unique=True, index=True, default=generate_tracking_token)
    tracking_expires_at = Column(DateTime(timezone=True), nullable=False, default=default_tracking_expires_at)
    tracking_revoked = Column(Boolean, nullable=False, default=False)

    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    customer = relationship("Customer", back_populates="orders")
    coupon = relationship("Coupon", back_populates="orders")
    order_items = relationship("OrderItem", back_populates="order", cascade="all, delete-orphan")
    payments = relationship("OrderPayment", back_populates="order", cascade="all, delete-orphan")
    coupon_redemptions = relationship("CouponRedemption", back_populates="order", cascade="all, delete-orphan")
